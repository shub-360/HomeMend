-- 03_user_roles_signup_trigger.sql
-- Assign default role + auto-create profile on signup

------------------------------------------------------------
-- 1. Create signup trigger function
------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.assign_default_role_on_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  ------------------------------------------------------------
  -- Assign default "user" role
  ------------------------------------------------------------
  INSERT INTO public.user_roles (user_id, role)
  SELECT NEW.id, 'user'
  WHERE NOT EXISTS (
    SELECT 1 
    FROM public.user_roles 
    WHERE user_id = NEW.id 
      AND role = 'user'
  );

  ------------------------------------------------------------
  -- Auto-create default profile row
  ------------------------------------------------------------
  INSERT INTO public.profiles (user_id, full_name, created_at)
  SELECT NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), now()
  WHERE NOT EXISTS (
    SELECT 1 
    FROM public.profiles 
    WHERE user_id = NEW.id
  );

  RETURN NEW;
END;
$$;

------------------------------------------------------------
-- 2. Create trigger on auth.users
------------------------------------------------------------
DROP TRIGGER IF EXISTS on_auth_user_created_roles ON auth.users;

CREATE TRIGGER on_auth_user_created_roles
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.assign_default_role_on_signup();
