-- 04_profiles_table_and_policies.sql
-- Ensure the profiles table exists (your CREATE TABLE probably already ran).
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Remove old policies to avoid overlap
DROP POLICY IF EXISTS "Users can manage their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;

-- Unified safe policy: owner OR admin (auth.uid() wrapped)
CREATE POLICY "profiles_unified_policy"
  ON public.profiles
  FOR ALL
  USING (
    (SELECT auth.uid()) = user_id
    OR EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = (SELECT auth.uid()) AND role = 'admin'
    )
  )
  WITH CHECK ((SELECT auth.uid()) = user_id);
