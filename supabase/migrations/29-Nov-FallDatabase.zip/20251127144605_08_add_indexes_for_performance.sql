-- 08_realtime_publications.sql
-- Add tables to Supabase realtime safely (no duplicates)

DO $$
BEGIN
  -- profiles
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  -- orders
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  -- cart_items
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.cart_items;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;
