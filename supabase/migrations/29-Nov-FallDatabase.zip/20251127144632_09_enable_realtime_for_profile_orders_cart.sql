-- 09_performance_indexes_and_maintenance.sql
-- High-performance indexes (no VACUUM needed)

------------------------------------------------------------
-- 1. Profiles: fetch by user_id
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_profiles_user_id
ON public.profiles (user_id);

------------------------------------------------------------
-- 2. Orders: fetch by user_id
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_orders_user_id
ON public.orders (user_id);

------------------------------------------------------------
-- 3. Orders: fetch by assigned_to (tech)
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_orders_assigned_to
ON public.orders (assigned_to);

------------------------------------------------------------
-- 4. Cart: fetch by user_id
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_cart_items_user_id
ON public.cart_items (user_id);

------------------------------------------------------------
-- 5. user_roles: optimize has_role() usage
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id_role
ON public.user_roles (user_id, role);
