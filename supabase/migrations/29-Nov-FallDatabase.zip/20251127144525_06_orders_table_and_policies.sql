-- 06_cart_items_table_and_final_policies.sql
-- Final cart system: zero warnings, clean RLS, fast index, safe policies

------------------------------------------------------------
-- 1. Create cart_items table
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.cart_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  service_type TEXT NOT NULL,
  description TEXT,
  price NUMERIC,
  scheduled_date TIMESTAMPTZ,
  preferred_time TEXT,
  customer_name TEXT,
  customer_phone TEXT,
  customer_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;

------------------------------------------------------------
-- 2. Drop old policies
------------------------------------------------------------
DROP POLICY IF EXISTS "cart_select_policy" ON public.cart_items;
DROP POLICY IF EXISTS "cart_insert_policy" ON public.cart_items;
DROP POLICY IF EXISTS "cart_update_policy" ON public.cart_items;
DROP POLICY IF EXISTS "cart_delete_policy" ON public.cart_items;
DROP POLICY IF EXISTS "cart_user_policy" ON public.cart_items;

------------------------------------------------------------
-- 3. Clean, unified policy (zero warnings)
------------------------------------------------------------
CREATE POLICY "cart_user_policy"
  ON public.cart_items
  FOR ALL
  USING (
    (SELECT auth.uid()) = user_id
  )
  WITH CHECK (
    (SELECT auth.uid()) = user_id
  );

------------------------------------------------------------
-- 4. updated_at trigger
------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_cart_items_updated_at'
  ) THEN
    CREATE TRIGGER update_cart_items_updated_at
    BEFORE UPDATE ON public.cart_items
    FOR EACH ROW 
    EXECUTE FUNCTION public.update_updated_at_column();
  END IF;
END $$;

------------------------------------------------------------
-- 5. Index for performance
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_cart_user_id
ON public.cart_items (user_id);
