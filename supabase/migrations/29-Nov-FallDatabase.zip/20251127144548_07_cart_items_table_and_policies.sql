-- 07_avatar_bucket_and_final_policies.sql
-- Perfect, safe, and fast avatar storage configuration

------------------------------------------------------------
-- 1. Create avatars bucket (safe, public)
------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

------------------------------------------------------------
-- 2. Remove ALL old policies for avatars
------------------------------------------------------------
DROP POLICY IF EXISTS "Avatar images are publicly accessible" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload their avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their avatar" ON storage.objects;
DROP POLICY IF EXISTS "avatar_select" ON storage.objects;
DROP POLICY IF EXISTS "avatar_insert" ON storage.objects;
DROP POLICY IF EXISTS "avatar_update" ON storage.objects;
DROP POLICY IF EXISTS "avatar_delete" ON storage.objects;

------------------------------------------------------------
-- 3. Public access to all avatar images
-- Required for displaying profile pictures
------------------------------------------------------------
CREATE POLICY "Avatar images are publicly accessible"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'avatars');

------------------------------------------------------------
-- 4. Users can UPLOAD only inside their own folder
-- REQUIRED PATH: 'userId/filename.jpg'
------------------------------------------------------------
CREATE POLICY "Users can upload their avatar"
  ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'avatars'
    AND name LIKE ( (SELECT auth.uid())::text || '/%' )
  );

------------------------------------------------------------
-- 5. Users can UPDATE only files in their own folder
------------------------------------------------------------
CREATE POLICY "Users can update their avatar"
  ON storage.objects
  FOR UPDATE
  USING (
    bucket_id = 'avatars'
    AND name LIKE ( (SELECT auth.uid())::text || '/%' )
  );

------------------------------------------------------------
-- 6. Users can DELETE only files in their own folder
------------------------------------------------------------
CREATE POLICY "Users can delete their avatar"
  ON storage.objects
  FOR DELETE
  USING (
    bucket_id = 'avatars'
    AND name LIKE ( (SELECT auth.uid())::text || '/%' )
  );
