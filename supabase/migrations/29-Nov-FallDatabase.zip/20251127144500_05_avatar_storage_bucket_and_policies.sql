-- 05_orders_table_and_final_policies.sql
-- Final optimized version: no overlapping policies, no recursion, fast queries

------------------------------------------------------------
-- 1. Create orders table
------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  service_type TEXT NOT NULL,
  description TEXT,
  price NUMERIC,
  scheduled_date TIMESTAMPTZ,
  preferred_time TEXT,
  customer_name TEXT,
  customer_phone TEXT,
  customer_address TEXT,
  assigned_to UUID, -- nullable (technician assignment)
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

------------------------------------------------------------
-- 2. Drop old / conflicting policies
------------------------------------------------------------
DROP POLICY IF EXISTS "orders_select_policy" ON public.orders;
DROP POLICY IF EXISTS "orders_insert_policy" ON public.orders;
DROP POLICY IF EXISTS "orders_update_policy" ON public.orders;
DROP POLICY IF EXISTS "orders_delete_policy" ON public.orders;

DROP POLICY IF EXISTS "orders_owner_policy" ON public.orders;
DROP POLICY IF EXISTS "orders_user_policy" ON public.orders;
DROP POLICY IF EXISTS "orders_technician_policy" ON public.orders;
DROP POLICY IF EXISTS "orders_technician_view" ON public.orders;
DROP POLICY IF EXISTS "orders_admin_policy" ON public.orders;

------------------------------------------------------------
-- 3. Clean, non-overlapping, zero-warning RLS policies
------------------------------------------------------------

-- 3.1 Users can fully manage their own orders
CREATE POLICY "orders_user_policy"
  ON public.orders
  FOR ALL
  USING (
    (SELECT auth.uid()) = user_id
  )
  WITH CHECK (
    (SELECT auth.uid()) = user_id
  );

-- 3.2 Technicians can ONLY view orders assigned to them
CREATE POLICY "orders_technician_view"
  ON public.orders
  FOR SELECT
  USING (
    assigned_to = (SELECT auth.uid())
    AND EXISTS (
      SELECT 1
      FROM public.user_roles
      WHERE user_id = (SELECT auth.uid())
      AND role = 'technician'
    )
  );

-- 3.3 Admin has FULL control over everything
CREATE POLICY "orders_admin_policy"
  ON public.orders
  FOR ALL
  USING (
    public.has_role((SELECT auth.uid()), 'admin')
  )
  WITH CHECK (
    public.has_role((SELECT auth.uid()), 'admin')
  );

------------------------------------------------------------
-- 4. Auto update updated_at field
------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_orders_updated_at'
  ) THEN
    CREATE TRIGGER update_orders_updated_at
    BEFORE UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
  END IF;
END $$;

------------------------------------------------------------
-- 5. Index for fast technician lookup
------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_orders_assigned_to 
ON public.orders (assigned_to);
